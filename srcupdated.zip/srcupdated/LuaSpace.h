// Copyright © 2008-2014 Pioneer Developers. See AUTHORS.txt for details
// Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

#ifndef _LUASPACE_H
#define _LUASPACE_H

namespace LuaSpace {
	void Register();
}

#endif
