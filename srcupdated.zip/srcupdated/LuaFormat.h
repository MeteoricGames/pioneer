// Copyright © 2008-2014 Pioneer Developers. See AUTHORS.txt for details
// Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

#ifndef _LUADATE_H
#define _LUADATE_H

namespace LuaFormat {
	void Register();
}

#endif
