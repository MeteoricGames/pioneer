// Copyright © 2008-2014 Pioneer Developers. See AUTHORS.txt for details
// Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

#ifndef LUAEQUIPDEF_H
#define LUAEQUIPDEF_H

namespace LuaEquipDef {
	void Register();
}

#endif
