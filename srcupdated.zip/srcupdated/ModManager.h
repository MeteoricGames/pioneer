// Copyright © 2008-2014 Pioneer Developers. See AUTHORS.txt for details
// Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

#ifndef _MODMANAGER_H
#define _MODMANAGER_H

// right now this is little more than a stub class to hook up zipfiles to the
// virtual filesystem

class ModManager {
public:
	static void Init();
};

#endif
