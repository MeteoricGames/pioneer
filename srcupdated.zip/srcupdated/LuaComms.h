// Copyright © 2008-2014 Pioneer Developers. See AUTHORS.txt for details
// Licensed under the terms of the GPL v3. See licenses/GPL-3.txt

#ifndef _LUACOMMS_H
#define _LUACOMMS_H

namespace LuaComms {
	void Register();
}

#endif
